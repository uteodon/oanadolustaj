package com.emresahin.OrtaAnadolu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrtaAnadoluApplicationTests {

	@Test
	void contextLoads() {
	}

}
