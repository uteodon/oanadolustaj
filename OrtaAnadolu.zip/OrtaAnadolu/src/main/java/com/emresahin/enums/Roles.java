package com.emresahin.enums;

public enum Roles {
	
	Admin,
	User,
	Manager

}
