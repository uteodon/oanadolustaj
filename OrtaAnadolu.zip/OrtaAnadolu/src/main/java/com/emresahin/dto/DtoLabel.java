package com.emresahin.dto;

import lombok.Data;

@Data
public class DtoLabel {
	
	private DtoUser user;
	
	private DtoFile file;

}
