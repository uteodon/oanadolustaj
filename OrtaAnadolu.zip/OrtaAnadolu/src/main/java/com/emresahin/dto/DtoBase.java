package com.emresahin.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DtoBase {
	
	private Long id;

}
